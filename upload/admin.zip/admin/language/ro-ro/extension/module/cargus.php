<?php
// Heading
$_['heading_title']     = 'Cargus';
$_['text_edit']         = 'Editare modul Cargus';
