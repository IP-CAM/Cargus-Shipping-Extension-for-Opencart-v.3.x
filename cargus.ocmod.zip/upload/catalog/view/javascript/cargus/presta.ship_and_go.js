
$(window).keydown(function(event){
    if(event.keyCode == 13) {
        event.preventDefault();
        return false;
    }
});

function addScriptOrStyle(path, callback) {
    var script = document.createElement("script");
    script.type = 'text/javascript';
    script.src = path;
    script.onload = callback;
    document.head.appendChild(script);
}

addScriptOrStyle(cargus_url + 'modules/cargus/assets/js/widget.js?v=1', function() {
(function() {
    // Setup map
    var widget = new Widget({
        key: 'online',
        initialPosition: {
            latitude: '44.435701',
            longitude: '26.101646'
        },
        selectedLocationId: null,
        mapSelector: 'map',
        containerSelector: '#widget',
        width: '100%',
        height: '600px',
        zoomEnabled: 'true',
        defaultZoomLevel: '13',
        pinIcon: 'null',
        lang: 'EN',
        apiUrl: 'https://app.urgentcargus.ro/map',
        showChooseButton: true,
        showOnlyShipGo: true,
        showOnlyApm: true,
        style: {
            font: 'Arial, Helvetica, sans-serif',
            backgroundColor: 'white',
            textColor: 'black',
            spinnerColor: '#F1A832',
            sidebar: {
                buttonTextColor: 'white',
                buttonTextHoverColor: 'white',
                buttonBackgroundColor: '#F1A832',
                buttonBackgroundHoverColor: 'darkorange',

                pudoItemTextColor: '#666',
                pudoItemBackgroundColor: '#eee',
                pudoItemTextHoverColor: '#666',
                pudoItemBackgroundHoverColor: 'lightgray',

                pudoItemSelectedTextColor: 'white',
                pudoItemSelectedBackgroundColor: '#F1A832',
                pudoItemSelectedButtonTextColor: '#4d4d4d',
                pudoItemSelectedButtonBackgroundColor: 'white',
                pudoItemSelectedButtonTextHoverColor: 'white',
                pudoItemSelectedButtonBackgroundHoverColor: 'darkorange'
            },
            popup: {
                backgroundColor: 'white',
                mainTextColor: '#4d4d4d',
                detailsTextColor: '#666',
                buttonTextColor: 'white',
                buttonBackgroundColor: '#F1A832',
                buttonTextHoverColor: 'white',
                buttonBackgroundHoverColor: 'darkorange',
            }
        }
    });
    widget.init();

    $( '#shipgomap-modal' ).on( 'shown.bs.modal', function () {
        if (Widget.instance.map) {
            Widget.instance.map.invalidateSize(true);
        }
    } );

    $( document ).ready(function() {
        if ((parseInt($("#js-delivery input[type='radio']:checked").val()) == CARGUS_SHIP_GO_CARRIER_ID) && !widget.selectedLocation) {

            $('button.continue').prop('disabled', true);
        }
    });

    $(document).on("click","input[type='radio']", function(){
        var selectedValue = parseInt($(this).val());

        if (selectedValue == CARGUS_SHIP_GO_CARRIER_ID) {
            // Check if any location selected
            // If not disable continue button
            if (! widget.selectedLocation) {
                $('button.continue').prop('disabled', true);
            } else {
                $('button.continue').prop('disabled', false);
            }
        } else {
            $('button.continue').prop('disabled', false);
        }
    });

    widget.onChanged = function(location) {
        var spinner = $('.spinner-border').removeClass('d-none');

        spinner.removeClass('d-none');

        $.ajax({
            type: "POST",
            url: "index.php?fc=module&module=cargus&controller=location",
            cache: false,
            data: JSON.stringify({location_id: location.Id}),
            contentType: "application/json; charset=utf-8",
            dataType: "json",
            success: function(data){
                checkAndRenderContinue(data, location);
                spinner.addClass('d-none');
            },
            error: function(data) {
                checkAndRenderContinue(data, location);
                spinner.addClass('d-none');
            }
        });
    };

    function checkAndRenderContinue(data, location) {
        var continueButton      = $('button.continue:visible');
        var continueButtonExtra = $('button.continue-extra');
        var locationInfoAlert = $('.location-alert');
        var locationErrorAlert = $('.location-error');

        if (!data.responseText.includes('ERROR')) {
            locationInfoAlert.html(createAlertHTML(location));
            locationInfoAlert.removeClass('d-none');

            widget.selectedLocation = location;
            widget.map.closePopup();


            continueButton.prop('disabled', false);

            continueButtonExtra.removeClass('d-none');
            locationErrorAlert.addClass('d-none');

            $('html, body').animate({
                scrollTop: $(".continue-extra").offset().top
            }, 200);

            bootstrap.Modal.getOrCreateInstance(document.getElementById('shipgomap-modal')).hide();
        } else {
            continueButton.prop('disabled', true);
            locationErrorAlert.removeClass('d-none');
            widget.map.closePopup();
        }
    }
    createAlertHTML = function (location) {
        var locationPaymentsString = 'Locatie aleasa : <b>' + location.Name + '</b><br/>';

        return locationPaymentsString;
    }

})();

});