<?php
$_['text_title'] = 'Curier';
$_['text_description'] = 'Livrare cu Cargus Ship & Go';
$_['text_description_2'] = 'Ridicare de la cel mai apropiat depozit Cargus';
$_['text_discount_urgent'] = 'Promotie valoare comanda';