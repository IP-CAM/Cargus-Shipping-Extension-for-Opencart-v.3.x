<?php

class ControllerExtensionModuleCargus extends Controller {
    public function index() {

    }

    public function install() {
        $this->log->write('admin ControllerExtensionModuleCargus install');
    }

    public function uninstall() {
        $this->log->write('admin ControllerExtensionModuleCargus uninstall');
    }

    public function event($route, &$args, &$output) {
        $this->log->write('admin mod');
        $this->log->write('Route: ' . $route);
        $this->log->write('Order Info: ');
        $this->log->write($args);
        $this->log->write('Order ID: ' . $output);
    }
}
